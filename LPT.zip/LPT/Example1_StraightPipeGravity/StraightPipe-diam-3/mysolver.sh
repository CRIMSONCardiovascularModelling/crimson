#!/bin/bash

if [[ $# -eq 0 ]] ; then
    echo 'number of processors not specified. Run ./mysolver 4 to use 4 processors'
    exit 1
fi
source /opt/conda/etc/profile.d/conda.sh
conda deactivate
ulimit -s unlimited
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export PHASTA_CONFIG="/app/configs"
export CRIMSON_FLOWSOLVER_HOME="/app"


# generate the initial particle data
conda activate genpart
python $CRIMSON_FLOWSOLVER_HOME/scripts/genpart 1>stdout 2>stderr
conda deactivate


# run the flowsolver
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/conda/envs/flow/lib
mpirun --oversubscribe -np $1 $CRIMSON_FLOWSOLVER_HOME/bin/flowsolver ./solver.inp 1>>stdout 2>>stderr