import numpy as np

######################################################################################
# USER INPUT
######################################################################################
particle_spacing  = 0.40
particle_diameter = 0.10
bolus_center = np.array([0.0,0.0,-16.0])
bolus_diameter = 8.0

# bounding box for the ball
box = np.array([bolus_center - 0.5*bolus_diameter, bolus_center + 0.5*bolus_diameter], dtype=np.float64)

# distance function for a sphere centered at bolus_center with diameter bolus_diameter
def dist_fun(x):
  return 0.5*bolus_diameter - np.sqrt(np.sum((x-bolus_center)**2))

# Extra option for the particle generator
n_trials = 10 # set this higher for a tighter packing, but it will take longer. try no greater then 50
